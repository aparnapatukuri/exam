package exam;

import java.util.ArrayList;
import java.util.List;

public class NoColl {
	 public static void main(String args[]){
         
	        List<Integer> li = new ArrayList<Integer>();
	        li.add(90);
	        li.add(90);
	        li.add(25);
	        li.add(63);
	        li.add(4);
	        System.out.println("print the value of array list:" +li);
	        for(int k=0;k<li.size();k++)
	        {
	        	for(int j=k+1;j<li.size();j++)
	        	{
	        		if (li.get(k).equals(li.get(j)))
	        		{
	        			li.remove(j);
	        			j--;
	        		}
	        	}
	        }
	        
	        System.out.println("the values of array:" +li);
	 }
	 
}
