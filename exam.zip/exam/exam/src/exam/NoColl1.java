package exam;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

public class NoColl1 {
	public static void main(String args[]){
        
        List<Integer> li = new ArrayList<Integer>();
        li.add(75);
        li.add(75);
        li.add(66);
        li.add(97);
        System.out.println("print the value of array list:" +li);
        LinkedHashSet<Integer> linkedhashset=new LinkedHashSet<Integer>();
        linkedhashset.addAll(li);
        li.clear();
        li.addAll(linkedhashset);
       
        
        System.out.println("the values of array:" +li);
 }
 

}
