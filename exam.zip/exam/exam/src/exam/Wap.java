package exam;

import java.util.ArrayList;
import java.util.List;

public class Wap {
public static void main(String args[])
{
	 List<Integer> li = new ArrayList<Integer>();
	li.add(75);
	li.add(97);
	li.add(21);
	int k =li.size();
	System.out.println("no.of elements:" +k);
}
}
