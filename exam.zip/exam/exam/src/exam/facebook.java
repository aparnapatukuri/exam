package exam;

import java.util.Scanner;

public class facebook {
	public static void main(String args[])
	{
		
	
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the value of lenght:");
	 int L=sc.nextInt();
	int dim;
	dim=L*L;
	
	Scanner wd= new Scanner(System.in);
	System.out.println("enter the value of width:");
		int W=wd.nextInt();
		Scanner ht=new Scanner(System.in);
		System.out.println("enter the value of height:");
		int H=ht.nextInt();
		 
		int pd=W*H;
		
		if(pd==dim)
		{
			
			System.out.println("photo accepted");
			
			
		}
		else{
			System.out.println("crop the photo");
		}
		if(H<L)
		{
			System.out.println("Upload next photo");
		}
}
}