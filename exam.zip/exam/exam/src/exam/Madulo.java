package exam;

public class Madulo {
	public static void main (String args[])
	{
		int [] a= new int[] {1,7,3,5};
		
		int num = 1;
		for(int i=0;i<a.length;i++)
		{
			
			num=num*a[i];
		}
		System.out.println("the value of num is:" +num);
	}
}
