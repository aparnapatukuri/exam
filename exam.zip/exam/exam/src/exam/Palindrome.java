package exam;

import java.util.Scanner;
import java.io.*;
public class Palindrome {
	public static void main (String args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the String:");
		String word=sc.nextLine();
		String Reverse="";
		int len= word.length();
		for(int i=len-1;i>=0;i--)
		{
			Reverse=Reverse+word.charAt(i);		
			System.out.println("print:"+Reverse);
		}
		if(word.equals(Reverse))
		{
			System.out.println("String is palindrome");
			
		}
		else
		{
			System.out.println("String is not palindrome");
			
		}
	}

	
}
