package exam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MaxList {
	
	    public static void main(String args[]){
	         
	        List<Integer> li = new ArrayList<Integer>();
	        li.add(100);
	        li.add(44);
	        li.add(120);
	        li.add(45);
	        li.add(2);
	        li.add(16);
	        System.out.println("Maximum element from the list: "+Collections.max(li));
	    }
	}
	

