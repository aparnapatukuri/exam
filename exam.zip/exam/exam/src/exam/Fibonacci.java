package exam;

public class Fibonacci {
	public static void main(String args[]){
        
		int a=0 , b=0 , c=1;
		System.out.println(a);
		System.out.println(b);
		for(int i=0;i<15;i++)
		{
		a=b;
		b=c;
		c=a+b;
		System.out.println(c);
		}

		}

		}