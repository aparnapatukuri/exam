package exam;

import java.util.ArrayList;

public class dues {
	public static void main(String[] args) {
		String input = "aJava2Novice2";
		ArrayList<Character> used = new ArrayList<>();
		for(int i = 0 ; i < input.length(); i++)
		{
		if(!used.contains(input.charAt(i)))
		{ 
		int count = 0;
		for(int j = 0; j < input.length(); j++)
		{
		if(input.charAt(i) == input.charAt(j))
		{
		count++;
		}

		}
		if(count > 1)
		{
		System.out.println(input.charAt(i)+" "+ (count));
		}
		used.add(input.charAt(i));
		}
		}
		}
		}