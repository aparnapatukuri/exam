package exam;

import java.util.Scanner;

public class Count {
	public static void main (String args[])
	{
		Scanner in =new Scanner(System.in);
		System.out.println("Enter integers:");
		int l=in.nextInt();
		int r=in.nextInt();
		int k=in.nextInt();
		
		int count=0;
		for(int i=l;i<=r;i++)
		{
			if(i%k==0)
			{
				count++;
				System.out.println("value:"+count);
			}
			
			else
			{
				System.out.println("it is not divisable");
			}
		}
		
	}
}
