package exam;

public class Example {
	public static void main (String args[])
	{
		
		
		int a[]={1,24,78,3,42,7,45};
		
		for(int i=0;i<a.length;i++)
		{
			
		System.out.println(a[i]);
			
			if(a[i]==42)
				
			{
				
				break;
			}
		
	}
	}
}
