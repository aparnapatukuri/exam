package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sorting {
	public static void main(String args[])
	{
		List al=new ArrayList<>();
		
		
		//al.add(new Integer("75"));
		
		//al.add(new Integer("66"));
		
		//al.add(new Integer("97"));
		al.add(new String("niba"));
		al.add(new String("mary"));
		al.add(new String("appu"));
		System.out.println("before sorting :" +al);
		 Collections.sort(al);
		 System.out.println("after sorting :" +al);
	}
	
}
