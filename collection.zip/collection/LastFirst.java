package collection;

import java.util.TreeSet;

public class LastFirst {
	public static void main(String args[])
	{
	TreeSet<String> ts = new TreeSet<String>();
	
	 ts.add("Aparna");
	 ts.add("niba");
	 ts.add("mary");
	
	 System.out.println("Lowest value Stored in Java TreeSet is : " + ts.first());
	    System.out.println("Highest value Stored in Java TreeSet is : " + ts.last());

	}
}
