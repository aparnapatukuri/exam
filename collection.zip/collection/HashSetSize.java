package collection;

import java.util.HashSet;

public class HashSetSize {
	 public static void main(String[] args) {
		   
		     HashSet hSet = new HashSet();
		   
		   System.out.println("Size of HashSet : " + hSet.size());
		   
		    hSet.add(new Integer("75"));
		    hSet.add(new Integer("21"));
		    hSet.add(new Integer("97"));
		 
		    System.out.println("Size of HashSet : "+ hSet.size());
		    hSet.add(new String("appu"));
		    hSet.add(new String("mary"));
		    hSet.add(new String("niba"));
		    System.out.println("Size of HashSet : " + hSet.size());
}
}