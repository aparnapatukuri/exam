package collection;

import java.util.HashSet;

public class CopyHashSetInt {
public static void main(String args[])
{
	HashSet<Integer> hSet= new HashSet<Integer>();
	hSet.add(new Integer(75));
	hSet.add(new Integer(66));
	hSet.add(new Integer(97));
	Object [] objArray= hSet.toArray();
	System.out.println("Copied Elements:");
	for(int i=0;i<objArray.length;i++)
	{
		System.out.println("numbers:" +objArray[i]);
	}
	
	
}
}
