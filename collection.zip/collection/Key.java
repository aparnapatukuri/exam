package collection;

import java.util.HashMap;

public class Key {
public static void main (String args[])
{
	 HashMap<Integer, String> student = new HashMap<Integer, String>();
	 student.put(24,"Aparna");
	 student.put(29,"Niba");
	 student.put(26,"Disha");
	 student.put(51,"Prashant");
	  boolean bl = student.containsKey(24);
	    System.out.println("Key 24 exists in HashMap? : " + bl);
	 
	    boolean bl1 = student.containsKey(52);
	    System.out.println("Key 52 exists in HashMap? : " + bl1);
	 
	  
}
}
