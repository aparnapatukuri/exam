package collection;

import java.util.HashSet;

public class CopyHashSet {
	 public static void main(String[] args) {
		 
		  
		    HashSet<String> hSet = new HashSet<String>();
		   
		    
		    hSet.add(new String("appu"));
		    hSet.add(new String("mary"));
		    hSet.add(new String("niba"));
		    Object[] objArray= hSet.toArray();
		    System.out.println("Copied elements:");
		    for(int i=0;i<objArray.length;i++)
		    {
		    System.out.println("elements:" +objArray[i]);	
		    }
}
}
