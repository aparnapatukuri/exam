package collection;

import java.util.HashMap;

public class RemoveKey {
	public static void main(String args[])
	{
		 HashMap<Integer, String> student = new HashMap<Integer, String>();
		 student.put(24,"Aparna");
		 student.put(29,"Niba");
		 student.put(26,"Disha");
		 student.put(51,"Prashant");
		 System.out.println("all students:" +student);
		   Object s1 = student.remove(26);
		    System.out.println("\nElement removed is: " +s1);
		    System.out.println("\nStudent Elements: " + student);
	}

}
