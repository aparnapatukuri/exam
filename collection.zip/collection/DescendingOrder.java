package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DescendingOrder {
public static void main (String args[])
{
	 ArrayList al = new ArrayList<>();
	   
	    al.add(new String("appu"));
	    al.add(new String("mary"));
	    al.add(new String("niba"));
	    al.add(new String("zxx"));
//	    al.add(new Integer("75"));
//		al.add(new Integer("66"));
//		al.add(new Integer("97"));
//		al.add(new Integer("970"));
	    Comparator comparator = Collections.reverseOrder();
	    Collections.sort(al,comparator);
	    System.out.println("descending order:" +al);
}
}
